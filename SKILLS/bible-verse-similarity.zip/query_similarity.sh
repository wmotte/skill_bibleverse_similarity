#!/bin/bash
# Wrapper script for Bible verse similarity queries
# Usage: ./query_similarity.sh "John 3:16" [top_n]

set -e

# Get the directory where this script lives
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Parent directory is the repository root
REPO_ROOT="$(dirname "$SCRIPT_DIR")"

# Default values
TOP_N="${2:-10}"

if [ -z "$1" ]; then
    echo "Usage: $0 \"VERSE_REFERENCE\" [TOP_N]"
    echo ""
    echo "Examples:"
    echo "  $0 \"John 3:16\""
    echo "  $0 \"John 3:16\" 15"
    echo "  $0 \"Psalm 23:1\" 5"
    exit 1
fi

# Change to repository root and run the query
cd "$REPO_ROOT"
python3 03__query_with_bgt.py --reference "$1" --top "$TOP_N"
